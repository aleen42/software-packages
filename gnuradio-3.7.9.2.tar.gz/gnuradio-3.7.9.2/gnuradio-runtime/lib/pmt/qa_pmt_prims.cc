/* -*- c++ -*- */
/*
 * Copyright 2006,2009,2010 Free Software Foundation, Inc.
 *
 * This file is part of GNU Radio
 *
 * GNU Radio is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 *
 * GNU Radio is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GNU Radio; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#include <qa_pmt_prims.h>
#include <cppunit/TestAssert.h>
#include <gnuradio/messages/msg_passing.h>
#include <boost/format.hpp>
#include <cstdio>
#include <cstring>
#include <sstream>

void
qa_pmt_prims::test_symbols()
{
  CPPUNIT_ASSERT(!pmt::is_symbol(pmt::PMT_T));
  CPPUNIT_ASSERT(!pmt::is_symbol(pmt::PMT_F));
  CPPUNIT_ASSERT_THROW(pmt::symbol_to_string(pmt::PMT_F), pmt::wrong_type);

  pmt::pmt_t sym1 = pmt::mp("test");
  CPPUNIT_ASSERT(pmt::is_symbol(sym1));
  CPPUNIT_ASSERT_EQUAL(std::string("test"), pmt::symbol_to_string(sym1));
  CPPUNIT_ASSERT(pmt::is_true(sym1));
  CPPUNIT_ASSERT(!pmt::is_false(sym1));

  pmt::pmt_t sym2 = pmt::mp("foo");
  pmt::pmt_t sym3 = pmt::mp("test");
  CPPUNIT_ASSERT_EQUAL(sym1, sym3);
  CPPUNIT_ASSERT(sym1 != sym2);
  CPPUNIT_ASSERT(sym1 == sym3);

  static const int N = 2048;
  std::vector<pmt::pmt_t> v1(N);
  std::vector<pmt::pmt_t> v2(N);

  // generate a bunch of symbols
  for (int i = 0; i < N; i++){
    std::string buf = str(boost::format("test-%d") % i);
    v1[i] = pmt::mp(buf.c_str());
  }

  // confirm that they are all unique
  for (int i = 0; i < N; i++)
    for (int j = i + 1; j < N; j++)
      CPPUNIT_ASSERT(v1[i] != v1[j]);

  // generate the same symbols again
  for (int i = 0; i < N; i++){
    std::string buf = str(boost::format("test-%d") % i);
    v2[i] = pmt::mp(buf.c_str());
  }

  // confirm that we get the same ones back
  for (int i = 0; i < N; i++)
    CPPUNIT_ASSERT(v1[i] == v2[i]);
}

void
qa_pmt_prims::test_booleans()
{
  pmt::pmt_t sym = pmt::mp("test");
  CPPUNIT_ASSERT(pmt::is_bool(pmt::PMT_T));
  CPPUNIT_ASSERT(pmt::is_bool(pmt::PMT_F));
  CPPUNIT_ASSERT(!pmt::is_bool(sym));
  CPPUNIT_ASSERT_EQUAL(pmt::from_bool(false), pmt::PMT_F);
  CPPUNIT_ASSERT_EQUAL(pmt::from_bool(true), pmt::PMT_T);
  CPPUNIT_ASSERT_EQUAL(false, pmt::to_bool(pmt::PMT_F));
  CPPUNIT_ASSERT_EQUAL(true, pmt::to_bool(pmt::PMT_T));
  CPPUNIT_ASSERT_THROW(pmt::to_bool(sym), pmt::wrong_type);
}

void
qa_pmt_prims::test_integers()
{
  pmt::pmt_t p1 = pmt::from_long(1);
  pmt::pmt_t m1 = pmt::from_long(-1);
  CPPUNIT_ASSERT(!pmt::is_integer(pmt::PMT_T));
  CPPUNIT_ASSERT(pmt::is_integer(p1));
  CPPUNIT_ASSERT(pmt::is_integer(m1));
  CPPUNIT_ASSERT_THROW(pmt::to_long(pmt::PMT_T), pmt::wrong_type);
  CPPUNIT_ASSERT_EQUAL(-1L, pmt::to_long(m1));
  CPPUNIT_ASSERT_EQUAL(1L, pmt::to_long(p1));
}

void
qa_pmt_prims::test_uint64s()
{
  pmt::pmt_t p1 = pmt::from_uint64((uint64_t)1);
  pmt::pmt_t m1 = pmt::from_uint64((uint64_t)8589934592ULL);
  CPPUNIT_ASSERT(!pmt::is_uint64(pmt::PMT_T));
  CPPUNIT_ASSERT(pmt::is_uint64(p1));
  CPPUNIT_ASSERT(pmt::is_uint64(m1));
  CPPUNIT_ASSERT_THROW(pmt::to_uint64(pmt::PMT_T), pmt::wrong_type);
  CPPUNIT_ASSERT_EQUAL((uint64_t)8589934592ULL, (uint64_t)pmt::to_uint64(m1));
  CPPUNIT_ASSERT_EQUAL((uint64_t)1ULL, (uint64_t)pmt::to_uint64(p1));
}

void
qa_pmt_prims::test_reals()
{
  pmt::pmt_t p1 = pmt::from_double(1);
  pmt::pmt_t m1 = pmt::from_double(-1);
  CPPUNIT_ASSERT(!pmt::is_real(pmt::PMT_T));
  CPPUNIT_ASSERT(pmt::is_real(p1));
  CPPUNIT_ASSERT(pmt::is_real(m1));
  CPPUNIT_ASSERT_THROW(pmt::to_double(pmt::PMT_T), pmt::wrong_type);
  CPPUNIT_ASSERT_EQUAL(-1.0, pmt::to_double(m1));
  CPPUNIT_ASSERT_EQUAL(1.0, pmt::to_double(p1));
  CPPUNIT_ASSERT_EQUAL(1.0, pmt::to_double(pmt::from_long(1)));

  pmt::pmt_t p2 = pmt::from_float(1);
  pmt::pmt_t m2 = pmt::from_float(-1);
  CPPUNIT_ASSERT(pmt::is_real(p2));
  CPPUNIT_ASSERT(pmt::is_real(m2));
  CPPUNIT_ASSERT_THROW(pmt::to_float(pmt::PMT_T), pmt::wrong_type);
  CPPUNIT_ASSERT_EQUAL(float(-1.0), pmt::to_float(m2));
  CPPUNIT_ASSERT_EQUAL(float(1.0), pmt::to_float(p2));
  CPPUNIT_ASSERT_EQUAL(float(1.0), pmt::to_float(pmt::from_long(1)));
}

void
qa_pmt_prims::test_complexes()
{
  pmt::pmt_t p1 = pmt::make_rectangular(2, -3);
  pmt::pmt_t m1 = pmt::make_rectangular(-3, 2);
  pmt::pmt_t p2 = pmt::from_complex(2, -3);
  pmt::pmt_t m2 = pmt::from_complex(-3, 2);
  pmt::pmt_t p3 = pmt::from_complex(std::complex<double>(2, -3));
  pmt::pmt_t m3 = pmt::from_complex(std::complex<double>(-3, 2));
  CPPUNIT_ASSERT(!pmt::is_complex(pmt::PMT_T));
  CPPUNIT_ASSERT(pmt::is_complex(p1));
  CPPUNIT_ASSERT(pmt::is_complex(m1));
  CPPUNIT_ASSERT(pmt::is_complex(p2));
  CPPUNIT_ASSERT(pmt::is_complex(m2));
  CPPUNIT_ASSERT(pmt::is_complex(p3));
  CPPUNIT_ASSERT(pmt::is_complex(m3));
  CPPUNIT_ASSERT_THROW(pmt::to_complex(pmt::PMT_T), pmt::wrong_type);
  CPPUNIT_ASSERT_EQUAL(std::complex<double>(2, -3), pmt::to_complex(p1));
  CPPUNIT_ASSERT_EQUAL(std::complex<double>(-3, 2), pmt::to_complex(m1));
  CPPUNIT_ASSERT_EQUAL(std::complex<double>(2, -3), pmt::to_complex(p2));
  CPPUNIT_ASSERT_EQUAL(std::complex<double>(-3, 2), pmt::to_complex(m2));
  CPPUNIT_ASSERT_EQUAL(std::complex<double>(2, -3), pmt::to_complex(p3));
  CPPUNIT_ASSERT_EQUAL(std::complex<double>(-3, 2), pmt::to_complex(m3));
  CPPUNIT_ASSERT_EQUAL(std::complex<double>(1.0, 0), pmt::to_complex(pmt::from_long(1)));
  CPPUNIT_ASSERT_EQUAL(std::complex<double>(1.0, 0), pmt::to_complex(pmt::from_double(1.0)));
}

void
qa_pmt_prims::test_pairs()
{
  CPPUNIT_ASSERT(pmt::is_null(pmt::PMT_NIL));
  CPPUNIT_ASSERT(!pmt::is_pair(pmt::PMT_NIL));
  pmt::pmt_t s1 = pmt::mp("s1");
  pmt::pmt_t s2 = pmt::mp("s2");
  pmt::pmt_t s3 = pmt::mp("s3");


  CPPUNIT_ASSERT_EQUAL((size_t)0, pmt::length(pmt::PMT_NIL));
  CPPUNIT_ASSERT_THROW(pmt::length(s1), pmt::wrong_type);
  CPPUNIT_ASSERT_THROW(pmt::length(pmt::from_double(42)), pmt::wrong_type);

  pmt::pmt_t c1 = pmt::cons(s1, pmt::PMT_NIL);
  CPPUNIT_ASSERT(pmt::is_pair(c1));
  CPPUNIT_ASSERT(!pmt::is_pair(s1));
  CPPUNIT_ASSERT_EQUAL(s1, pmt::car(c1));
  CPPUNIT_ASSERT_EQUAL(pmt::PMT_NIL, pmt::cdr(c1));
  CPPUNIT_ASSERT_EQUAL((size_t) 1, pmt::length(c1));

  pmt::pmt_t c3 = pmt::cons(s3, pmt::PMT_NIL);
  pmt::pmt_t c2 = pmt::cons(s2, c3);
  pmt::set_cdr(c1, c2);
  CPPUNIT_ASSERT_EQUAL(c2, pmt::cdr(c1));
  pmt::set_car(c1, s3);
  CPPUNIT_ASSERT_EQUAL(s3, pmt::car(c1));
  CPPUNIT_ASSERT_EQUAL((size_t)1, pmt::length(c3));
  CPPUNIT_ASSERT_EQUAL((size_t)2, pmt::length(c2));

  CPPUNIT_ASSERT_THROW(pmt::cdr(pmt::PMT_NIL), pmt::wrong_type);
  CPPUNIT_ASSERT_THROW(pmt::car(pmt::PMT_NIL), pmt::wrong_type);
  CPPUNIT_ASSERT_THROW(pmt::set_car(s1, pmt::PMT_NIL), pmt::wrong_type);
  CPPUNIT_ASSERT_THROW(pmt::set_cdr(s1, pmt::PMT_NIL), pmt::wrong_type);
}

void
qa_pmt_prims::test_vectors()
{
  static const size_t N = 3;
  pmt::pmt_t v1 = pmt::make_vector(N, pmt::PMT_NIL);
  CPPUNIT_ASSERT_EQUAL(N, pmt::length(v1));
  pmt::pmt_t s0 = pmt::mp("s0");
  pmt::pmt_t s1 = pmt::mp("s1");
  pmt::pmt_t s2 = pmt::mp("s2");

  pmt::vector_set(v1, 0, s0);
  pmt::vector_set(v1, 1, s1);
  pmt::vector_set(v1, 2, s2);

  CPPUNIT_ASSERT_EQUAL(s0, pmt::vector_ref(v1, 0));
  CPPUNIT_ASSERT_EQUAL(s1, pmt::vector_ref(v1, 1));
  CPPUNIT_ASSERT_EQUAL(s2, pmt::vector_ref(v1, 2));

  CPPUNIT_ASSERT_THROW(pmt::vector_ref(v1, N), pmt::out_of_range);
  CPPUNIT_ASSERT_THROW(pmt::vector_set(v1, N, pmt::PMT_NIL), pmt::out_of_range);

  pmt::vector_fill(v1, s0);
  for (size_t i = 0; i < N; i++)
    CPPUNIT_ASSERT_EQUAL(s0, pmt::vector_ref(v1, i));
}

static void
check_tuple(size_t len, const std::vector<pmt::pmt_t> &s, pmt::pmt_t t)
{
  CPPUNIT_ASSERT_EQUAL(true, pmt::is_tuple(t));
  CPPUNIT_ASSERT_EQUAL(len, pmt::length(t));

  for (size_t i = 0; i < len; i++)
    CPPUNIT_ASSERT_EQUAL(s[i], pmt::tuple_ref(t, i));

}

void
qa_pmt_prims::test_tuples()
{
  pmt::pmt_t v = pmt::make_vector(10, pmt::PMT_NIL);
  std::vector<pmt::pmt_t> s(10);
  for (size_t i = 0; i < 10; i++){
    std::ostringstream os;
    os << "s" << i;
    s[i] = pmt::mp(os.str());
    pmt::vector_set(v, i, s[i]);
  }


  pmt::pmt_t t;

  t = pmt::make_tuple();
  check_tuple(0, s, t);

  t = pmt::make_tuple(s[0]);
  check_tuple(1, s, t);

  CPPUNIT_ASSERT(pmt::is_vector(v));
  CPPUNIT_ASSERT(!pmt::is_tuple(v));
  CPPUNIT_ASSERT(pmt::is_tuple(t));
  CPPUNIT_ASSERT(!pmt::is_vector(t));

  t = pmt::make_tuple(s[0], s[1]);
  check_tuple(2, s, t);

  t = pmt::make_tuple(s[0], s[1], s[2]);
  check_tuple(3, s, t);

  t = pmt::make_tuple(s[0], s[1], s[2], s[3]);
  check_tuple(4, s, t);

  t = pmt::make_tuple(s[0], s[1], s[2], s[3], s[4]);
  check_tuple(5, s, t);

  t = pmt::make_tuple(s[0], s[1], s[2], s[3], s[4], s[5]);
  check_tuple(6, s, t);

  t = pmt::make_tuple(s[0], s[1], s[2], s[3], s[4], s[5], s[6]);
  check_tuple(7, s, t);

  t = pmt::make_tuple(s[0], s[1], s[2], s[3], s[4], s[5], s[6], s[7]);
  check_tuple(8, s, t);

  t = pmt::make_tuple(s[0], s[1], s[2], s[3], s[4], s[5], s[6], s[7], s[8]);
  check_tuple(9, s, t);

  t = pmt::make_tuple(s[0], s[1], s[2], s[3], s[4], s[5], s[6], s[7], s[8], s[9]);
  check_tuple(10, s, t);

  t = pmt::make_tuple(s[0], s[1], s[2]);
  CPPUNIT_ASSERT_THROW(pmt::tuple_ref(t, 3), pmt::out_of_range);
  CPPUNIT_ASSERT_THROW(pmt::vector_ref(t, 0), pmt::wrong_type);
  CPPUNIT_ASSERT_THROW(pmt::tuple_ref(v, 0), pmt::wrong_type);

  t = pmt::make_tuple(s[0], s[1], s[2], s[3], s[4], s[5], s[6], s[7], s[8], s[9]);
  pmt::pmt_t t2 = pmt::to_tuple(v);
  CPPUNIT_ASSERT_EQUAL(size_t(10), pmt::length(v));
  CPPUNIT_ASSERT(pmt::equal(t, t2));
  //std::cout << v << std::endl;
  //std::cout << t2 << std::endl;


  t = pmt::make_tuple(s[0], s[1], s[2]);
  pmt::pmt_t list0 = pmt::list3(s[0], s[1], s[2]);
  CPPUNIT_ASSERT_EQUAL(size_t(3), pmt::length(list0));
  t2 = pmt::to_tuple(list0);
  CPPUNIT_ASSERT_EQUAL(size_t(3), pmt::length(t2));
  CPPUNIT_ASSERT(pmt::equal(t, t2));
}

void
qa_pmt_prims::test_equivalence()
{
  pmt::pmt_t s0 = pmt::mp("s0");
  pmt::pmt_t s1 = pmt::mp("s1");
  pmt::pmt_t s2 = pmt::mp("s2");
  pmt::pmt_t list0 = pmt::cons(s0, pmt::cons(s1, pmt::cons(s2, pmt::PMT_NIL)));
  pmt::pmt_t list1 = pmt::cons(s0, pmt::cons(s1, pmt::cons(s2, pmt::PMT_NIL)));
  pmt::pmt_t i0 = pmt::from_long(42);
  pmt::pmt_t i1 = pmt::from_long(42);
  pmt::pmt_t r0 = pmt::from_double(42);
  pmt::pmt_t r1 = pmt::from_double(42);
  pmt::pmt_t r2 = pmt::from_double(43);

  CPPUNIT_ASSERT(pmt::eq(s0, s0));
  CPPUNIT_ASSERT(!pmt::eq(s0, s1));
  CPPUNIT_ASSERT(pmt::eqv(s0, s0));
  CPPUNIT_ASSERT(!pmt::eqv(s0, s1));

  CPPUNIT_ASSERT(pmt::eqv(i0, i1));
  CPPUNIT_ASSERT(pmt::eqv(r0, r1));
  CPPUNIT_ASSERT(!pmt::eqv(r0, r2));
  CPPUNIT_ASSERT(!pmt::eqv(i0, r0));

  CPPUNIT_ASSERT(!pmt::eq(list0, list1));
  CPPUNIT_ASSERT(!pmt::eqv(list0, list1));
  CPPUNIT_ASSERT(pmt::equal(list0, list1));

  pmt::pmt_t v0 = pmt::make_vector(3, s0);
  pmt::pmt_t v1 = pmt::make_vector(3, s0);
  pmt::pmt_t v2 = pmt::make_vector(4, s0);
  CPPUNIT_ASSERT(!pmt::eqv(v0, v1));
  CPPUNIT_ASSERT(pmt::equal(v0, v1));
  CPPUNIT_ASSERT(!pmt::equal(v0, v2));

  pmt::vector_set(v0, 0, list0);
  pmt::vector_set(v0, 1, list0);
  pmt::vector_set(v1, 0, list1);
  pmt::vector_set(v1, 1, list1);
  CPPUNIT_ASSERT(pmt::equal(v0, v1));
}

void
qa_pmt_prims::test_misc()
{
  pmt::pmt_t k0 = pmt::mp("k0");
  pmt::pmt_t k1 = pmt::mp("k1");
  pmt::pmt_t k2 = pmt::mp("k2");
  pmt::pmt_t k3 = pmt::mp("k3");
  pmt::pmt_t v0 = pmt::mp("v0");
  pmt::pmt_t v1 = pmt::mp("v1");
  pmt::pmt_t v2 = pmt::mp("v2");
  pmt::pmt_t p0 = pmt::cons(k0, v0);
  pmt::pmt_t p1 = pmt::cons(k1, v1);
  pmt::pmt_t p2 = pmt::cons(k2, v2);

  pmt::pmt_t alist = pmt::cons(p0, pmt::cons(p1, pmt::cons(p2, pmt::PMT_NIL)));
  CPPUNIT_ASSERT(pmt::eq(p1, pmt::assv(k1, alist)));
  CPPUNIT_ASSERT(pmt::eq(pmt::PMT_F, pmt::assv(k3, alist)));

  pmt::pmt_t keys = pmt::cons(k0, pmt::cons(k1, pmt::cons(k2, pmt::PMT_NIL)));
  pmt::pmt_t vals = pmt::cons(v0, pmt::cons(v1, pmt::cons(v2, pmt::PMT_NIL)));
  CPPUNIT_ASSERT(pmt::equal(keys, pmt::map(pmt::car, alist)));
  CPPUNIT_ASSERT(pmt::equal(vals, pmt::map(pmt::cdr, alist)));
}

void
qa_pmt_prims::test_dict()
{
  pmt::pmt_t dict = pmt::make_dict();
  CPPUNIT_ASSERT(pmt::is_dict(dict));

  pmt::pmt_t k0 = pmt::mp("k0");
  pmt::pmt_t k1 = pmt::mp("k1");
  pmt::pmt_t k2 = pmt::mp("k2");
  pmt::pmt_t k3 = pmt::mp("k3");
  pmt::pmt_t v0 = pmt::mp("v0");
  pmt::pmt_t v1 = pmt::mp("v1");
  pmt::pmt_t v2 = pmt::mp("v2");
  pmt::pmt_t v3 = pmt::mp("v3");
  pmt::pmt_t not_found = pmt::cons(pmt::PMT_NIL, pmt::PMT_NIL);

  CPPUNIT_ASSERT(!pmt::dict_has_key(dict, k0));
  dict = pmt::dict_add(dict, k0, v0);
  CPPUNIT_ASSERT(pmt::dict_has_key(dict, k0));
  CPPUNIT_ASSERT(pmt::eqv(pmt::dict_ref(dict, k0, not_found), v0));
  CPPUNIT_ASSERT(pmt::eqv(pmt::dict_ref(dict, k1, not_found), not_found));
  dict = pmt::dict_add(dict, k1, v1);
  dict = pmt::dict_add(dict, k2, v2);
  CPPUNIT_ASSERT(pmt::eqv(pmt::dict_ref(dict, k1, not_found), v1));
  dict = pmt::dict_add(dict, k1, v3);
  CPPUNIT_ASSERT(pmt::eqv(pmt::dict_ref(dict, k1, not_found), v3));

  pmt::pmt_t keys = pmt::list3(k1, k2, k0);
  pmt::pmt_t vals = pmt::list3(v3, v2, v0);
  //std::cout << "pmt::dict_keys:   " << pmt::dict_keys(dict) << std::endl;
  //std::cout << "pmt::dict_values: " << pmt::dict_values(dict) << std::endl;
  CPPUNIT_ASSERT(pmt::equal(keys, pmt::dict_keys(dict)));
  CPPUNIT_ASSERT(pmt::equal(vals, pmt::dict_values(dict)));
}

void
qa_pmt_prims::test_io()
{
  pmt::pmt_t k0 = pmt::mp("k0");
  pmt::pmt_t k1 = pmt::mp("k1");
  pmt::pmt_t k2 = pmt::mp("k2");
  pmt::pmt_t k3 = pmt::mp("k3");

  CPPUNIT_ASSERT_EQUAL(std::string("k0"), pmt::write_string(k0));
}

void
qa_pmt_prims::test_lists()
{
  pmt::pmt_t s0 = pmt::mp("s0");
  pmt::pmt_t s1 = pmt::mp("s1");
  pmt::pmt_t s2 = pmt::mp("s2");
  pmt::pmt_t s3 = pmt::mp("s3");

  pmt::pmt_t l1 = pmt::list4(s0, s1, s2, s3);
  pmt::pmt_t l2 = pmt::list3(s0, s1, s2);
  pmt::pmt_t l3 = pmt::list_add(l2, s3);
  CPPUNIT_ASSERT(pmt::equal(l1, l3));
}

// ------------------------------------------------------------------------

// class foo is used in test_any below.
// It can't be declared in the scope of test_any because of template
// namespace problems.

class foo {
public:
  double	d_double;
  int		d_int;
  foo(double d=0, int i=0) : d_double(d), d_int(i) {}
};

bool operator==(const foo &a, const foo &b)
{
  return a.d_double == b.d_double && a.d_int == b.d_int;
}

std::ostream& operator<<(std::ostream &os, const foo obj)
{
  os << "<foo: " << obj.d_double << ", " << obj.d_int << ">";
  return os;
}

void
qa_pmt_prims::test_any()
{
  boost::any a0;
  boost::any a1;
  boost::any a2;

  a0 = std::string("Hello!");
  a1 = 42;
  a2 = foo(3.250, 21);

  pmt::pmt_t p0 = pmt::make_any(a0);
  pmt::pmt_t p1 = pmt::make_any(a1);
  pmt::pmt_t p2 = pmt::make_any(a2);

  CPPUNIT_ASSERT_EQUAL(std::string("Hello!"),
		       boost::any_cast<std::string>(pmt::any_ref(p0)));

  CPPUNIT_ASSERT_EQUAL(42,
		       boost::any_cast<int>(pmt::any_ref(p1)));

  CPPUNIT_ASSERT_EQUAL(foo(3.250, 21),
		       boost::any_cast<foo>(pmt::any_ref(p2)));
}

// ------------------------------------------------------------------------

class qa_pmt_msg_accepter_nop : public gr::messages::msg_accepter
{
public:
  qa_pmt_msg_accepter_nop(){};
  ~qa_pmt_msg_accepter_nop();
  void post(pmt::pmt_t,pmt::pmt_t){};
};

qa_pmt_msg_accepter_nop::~qa_pmt_msg_accepter_nop(){}

void
qa_pmt_prims::test_msg_accepter()
{
  pmt::pmt_t sym = pmt::mp("my-symbol");

  boost::any a0;
  a0 = std::string("Hello!");
  pmt::pmt_t p0 = pmt::make_any(a0);

  gr::messages::msg_accepter_sptr ma0 =                                 \
    gr::messages::msg_accepter_sptr(new qa_pmt_msg_accepter_nop());
  pmt::pmt_t p1 = pmt::make_msg_accepter(ma0);

  CPPUNIT_ASSERT_EQUAL(ma0.get(), pmt::msg_accepter_ref(p1).get());

  CPPUNIT_ASSERT_THROW(pmt::msg_accepter_ref(sym), pmt::wrong_type);
  CPPUNIT_ASSERT_THROW(pmt::msg_accepter_ref(p0),  pmt::wrong_type);

  // just confirm interfaces on send are OK
  pmt::pmt_t port(pmt::intern("port"));
  gr::messages::send(ma0.get(), port, sym);
  gr::messages::send(ma0, port, sym);
  gr::messages::send(p1, port, sym);

}

// ------------------------------------------------------------------------

void
qa_pmt_prims::test_serialize()
{
  std::stringbuf sb;		// fake channel
  pmt::pmt_t a = pmt::mp("a");
  pmt::pmt_t b = pmt::mp("b");
  pmt::pmt_t c = pmt::mp("c");

  sb.str("");			// reset channel to empty

  // write stuff to channel

  pmt::serialize(pmt::PMT_NIL, sb);
  pmt::serialize(pmt::mp("foobarvia"), sb);
  pmt::serialize(pmt::from_long(123456789), sb);
  pmt::serialize(pmt::from_long(-123456789), sb);
  pmt::serialize(pmt::cons(pmt::PMT_NIL, pmt::PMT_NIL), sb);
  pmt::serialize(pmt::cons(a, b), sb);
  pmt::serialize(pmt::list1(a), sb);
  pmt::serialize(pmt::list2(a, b), sb);
  pmt::serialize(pmt::list3(a, b, c), sb);
  pmt::serialize(pmt::list3(a, pmt::list3(c, b, a), c), sb);
  pmt::serialize(pmt::PMT_T, sb);
  pmt::serialize(pmt::PMT_F, sb);

  // read it back

  CPPUNIT_ASSERT(pmt::equal(pmt::deserialize(sb), pmt::PMT_NIL));
  CPPUNIT_ASSERT(pmt::equal(pmt::deserialize(sb), pmt::mp("foobarvia")));
  CPPUNIT_ASSERT(pmt::equal(pmt::deserialize(sb), pmt::from_long(123456789)));
  CPPUNIT_ASSERT(pmt::equal(pmt::deserialize(sb), pmt::from_long(-123456789)));
  CPPUNIT_ASSERT(pmt::equal(pmt::deserialize(sb), pmt::cons(pmt::PMT_NIL, pmt::PMT_NIL)));
  CPPUNIT_ASSERT(pmt::equal(pmt::deserialize(sb), pmt::cons(a, b)));
  CPPUNIT_ASSERT(pmt::equal(pmt::deserialize(sb), pmt::list1(a)));
  CPPUNIT_ASSERT(pmt::equal(pmt::deserialize(sb), pmt::list2(a, b)));
  CPPUNIT_ASSERT(pmt::equal(pmt::deserialize(sb), pmt::list3(a, b, c)));
  CPPUNIT_ASSERT(pmt::equal(pmt::deserialize(sb), pmt::list3(a, pmt::list3(c, b, a), c)));
  CPPUNIT_ASSERT(pmt::equal(pmt::deserialize(sb), pmt::PMT_T));
  CPPUNIT_ASSERT(pmt::equal(pmt::deserialize(sb), pmt::PMT_F));

  CPPUNIT_ASSERT(pmt::equal(pmt::deserialize(sb), pmt::PMT_EOF));	// last item


  // FIXME add tests for real, complex, vector, uniform-vector, dict
  // FIXME add tests for malformed input too.

}

void
qa_pmt_prims::test_sets()
{
  pmt::pmt_t s1 = pmt::mp("s1");
  pmt::pmt_t s2 = pmt::mp("s2");
  pmt::pmt_t s3 = pmt::mp("s3");

  pmt::pmt_t l1 = pmt::list1(s1);
  pmt::pmt_t l2 = pmt::list2(s2,s3);
  pmt::pmt_t l3 = pmt::list3(s1,s2,s3);

  CPPUNIT_ASSERT(pmt::is_pair(pmt::memq(s1,l1)));
  CPPUNIT_ASSERT(pmt::is_false(pmt::memq(s3,l1)));

  CPPUNIT_ASSERT(pmt::subsetp(l1,l3));
  CPPUNIT_ASSERT(pmt::subsetp(l2,l3));
  CPPUNIT_ASSERT(!pmt::subsetp(l1,l2));
  CPPUNIT_ASSERT(!pmt::subsetp(l2,l1));
  CPPUNIT_ASSERT(!pmt::subsetp(l3,l2));
}

void
qa_pmt_prims::test_sugar()
{
  CPPUNIT_ASSERT(pmt::is_symbol(pmt::mp("my-symbol")));
  CPPUNIT_ASSERT_EQUAL((long) 10, pmt::to_long(pmt::mp(10)));
  CPPUNIT_ASSERT_EQUAL((double) 1e6, pmt::to_double(pmt::mp(1e6)));
  CPPUNIT_ASSERT_EQUAL(std::complex<double>(2, 3),
		       pmt::to_complex(pmt::mp(std::complex<double>(2, 3))));

  int buf[10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
  pmt::pmt_t blob = pmt::mp(buf, sizeof(buf));
  const void *data = pmt::blob_data(blob);
  size_t nbytes = pmt::blob_length(blob);
  CPPUNIT_ASSERT_EQUAL(sizeof(buf), nbytes);
  CPPUNIT_ASSERT(memcmp(buf, data, nbytes) == 0);
}
