gnuradio.vocoder
================

.. autoclass:: gnuradio.vocoder.codec2
.. autoclass:: gnuradio.vocoder.cvsd_encode_fb
.. autoclass:: gnuradio.vocoder.cvsd_decode_bf
